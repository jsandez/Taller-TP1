#ifndef _COMMANDS_H_
#define _COMMANDS_H_

int decode(char *stdIn, char *message);

#endif
