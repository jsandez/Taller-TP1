#include "Board.h"

#ifndef _SUDOKUVIEW_H_
#define _SUDOKUVIEW_H_

void getBoardView(Board_t *board, char matrixView[722]);

#endif
